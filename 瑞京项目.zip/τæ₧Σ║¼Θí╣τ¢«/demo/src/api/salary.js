import request from '@/untils/http';

export function getSalaryDetail() {
    return request({
        method: 'get',
        url:'',
        params: '',
    })
}