<template>
  <div>
    <el-container>
      <el-header>
        <el-row type="flex" style="height: 100%; align-items: center">
          <el-col :span="3"><span>财务管理系统</span></el-col>
          <el-col :span="18"></el-col>
          <el-col :span="3"
            ><el-dropdown>
              <span>
                功能
                <i class="el-icon-arrow-down el-icon--right"></i>
              </span>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item v-for="item in menus" :key="item.id">{{
                  item.value
                }}</el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown></el-col
          >
        </el-row>
      </el-header>
      <el-container>
        <el-aside width="200px">
          <el-menu
            default-active="1"
            class="el-aside-menu"
            background-color="#545c64"
            text-color="#fff"
            active-text-color="#ffd04b"
          >
            <el-menu-item index="1" @click="goTo('/userManagement')"
              >用户管理</el-menu-item
            >
            <el-menu-item index="2" @click="goTo('/roleManagement')"
              >角色管理</el-menu-item
            >
            <el-menu-item index="3" @click="goTo('/permissionsManagement')"
              >权限管理</el-menu-item
            >
          </el-menu>
        </el-aside>
        <el-main>
          <slot></slot>
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<script>
export default {
  data() {
    return {
      menus: [
        {
          id: 1,
          value: '用户管理',
        },
        {
          id: 2,
          value: '角色管理',
        },
        {
          id: 3,
          value: '权限管理',
        },
      ],
    };
  },
  methods: {},
};
</script>

<style lang="scss" scoped>
.el-main {
  background-color: skyblue;
}

.el-aside {
  background-color: pink;
}

header {
  background-color: rgb(84, 92, 100);
}

.el-row span {
  color: #fff;
}
</style>
