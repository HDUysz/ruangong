import Axios from 'axios';

const http = Axios.create({
  baseURL: '',
  timeout: 10000,
});

export default http;
