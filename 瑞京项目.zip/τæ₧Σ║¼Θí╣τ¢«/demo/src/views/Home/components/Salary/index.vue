<template>
  <div>
    <el-table :height="250" border style="width: 100%">
      <el-table-colum> </el-table-colum>
    </el-table>
  </div>
</template>

<script>
export default {
  components: {},
  data() {
    return {
      tableData: {},
    };
  },
};
</script>

<style>
</style>