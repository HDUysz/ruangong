<template>
  <div>
    <Layout></Layout>
  </div>
</template>

<script>
import Layout from '@/components/Layout/index';
export default {
  components: {
    Layout,
  },
};
</script>

<style>
</style>
